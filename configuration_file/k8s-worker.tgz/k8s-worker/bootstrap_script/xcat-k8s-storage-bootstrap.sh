#!/usr/bin/env bash

###############################################################################
# xCAT Stateless Kubernetes Worker - Local Persistent Storage Bootstrap
#
# Purpose:
#   Prepare and mount persistent Kubernetes directories from the compute
#   node's local SSD on EVERY boot.
#
# Persistent directories:
#   /etc/kubernetes
#   /var/lib/kubelet
#   /var/lib/containerd
#
# Design:
#   xCAT manages the stateless OS.
#   Local SSD preserves node-specific Kubernetes state.
#
# IMPORTANT:
#   This script NEVER formats a disk automatically.
#   Disk initialization should be performed by xCAT/storage provisioning.
#
# Tested design:
#
#   Local SSD partition
#          |
#          v
#      /local/k8s
#          |
#          +-- etc-kubernetes
#          +-- kubelet
#          +-- containerd
#          |
#          +---- bind mount ----> /etc/kubernetes
#          |
#          +---- bind mount ----> /var/lib/kubelet
#          |
#          +---- bind mount ----> /var/lib/containerd
#
###############################################################################

set -Eeuo pipefail

###############################################################################
# Configuration
###############################################################################

SCRIPT_NAME="xcat-k8s-storage-bootstrap"
LOG_TAG="${SCRIPT_NAME}"

# ---------------------------------------------------------------------------
# Local SSD
# ---------------------------------------------------------------------------
#
# IMPORTANT:
# Prefer filesystem UUID instead of relying only on /dev/nvme0n1p1.
#
# Example:
#
#   SSD_DEVICE="/dev/nvme0n1"
#   SSD_PARTITION="/dev/nvme0n1p1"
#
# Set these according to your node.
#
###############################################################################

SSD_DEVICE="${SSD_DEVICE:-/dev/nvme0n1}"
SSD_PARTITION="${SSD_PARTITION:-/dev/nvme0n1p3}"

# Expected filesystem.
EXPECTED_FSTYPE="${EXPECTED_FSTYPE:-xfs}"

# ---------------------------------------------------------------------------
# Persistent storage mount point
# ---------------------------------------------------------------------------

K8S_STORAGE_ROOT="${K8S_STORAGE_ROOT:-/local/k8s}"

# ---------------------------------------------------------------------------
# Persistent Kubernetes directories
# ---------------------------------------------------------------------------

K8S_CONFIG_PERSIST="${K8S_STORAGE_ROOT}/etc-kubernetes"
KUBELET_PERSIST="${K8S_STORAGE_ROOT}/kubelet"
CONTAINERD_PERSIST="${K8S_STORAGE_ROOT}/containerd"

# ---------------------------------------------------------------------------
# Kubernetes directories
# ---------------------------------------------------------------------------

K8S_CONFIG="/etc/kubernetes"
KUBELET="/var/lib/kubelet"
CONTAINERD="/var/lib/containerd"

# ---------------------------------------------------------------------------
# Safety
# ---------------------------------------------------------------------------

# This script must NEVER format disks.
ALLOW_FORMAT="no"

###############################################################################
# Logging
###############################################################################

log()
{
    local level="$1"
    shift

    local message="$*"

    printf '[%s] [%s] %s\n' \
        "$(date '+%Y-%m-%d %H:%M:%S')" \
        "${level}" \
        "${message}"

    logger -t "${LOG_TAG}" \
        -- "${level}: ${message}" 2>/dev/null || true
}

info()
{
    log "INFO" "$@"
}

warn()
{
    log "WARN" "$@"
}

error()
{
    log "ERROR" "$@"
}

fatal()
{
    error "$@"
    exit 1
}

###############################################################################
# Error handler
###############################################################################

trap '
    rc=$?
    error "Bootstrap failed at line ${LINENO}: ${BASH_COMMAND} (rc=${rc})"
    exit "${rc}"
' ERR

###############################################################################
# Root check
###############################################################################

if [[ "${EUID}" -ne 0 ]]; then
    fatal "This script must run as root."
fi

###############################################################################
# Required commands
###############################################################################

REQUIRED_COMMANDS=(
    lsblk
    blkid
    findmnt
    mount
    mountpoint
    mkdir
    udevadm
)

for cmd in "${REQUIRED_COMMANDS[@]}"; do
    if ! command -v "${cmd}" >/dev/null 2>&1; then
        fatal "Required command not found: ${cmd}"
    fi
done

###############################################################################
# Wait for udev/device discovery
###############################################################################

info "Waiting for local storage devices."

udevadm settle --timeout=30 || true

###############################################################################
# Validate SSD device
###############################################################################

info "Checking local SSD device: ${SSD_DEVICE}"

if [[ ! -b "${SSD_DEVICE}" ]]; then
    fatal "Expected SSD device does not exist: ${SSD_DEVICE}"
fi

###############################################################################
# Validate SSD partition
###############################################################################

info "Checking expected SSD partition: ${SSD_PARTITION}"

if [[ ! -b "${SSD_PARTITION}" ]]; then
    fatal "Expected Kubernetes SSD partition does not exist: ${SSD_PARTITION}"
fi

###############################################################################
# Display storage information
###############################################################################

info "Local storage information:"

lsblk -o \
    NAME,TYPE,SIZE,FSTYPE,LABEL,UUID,MOUNTPOINTS \
    "${SSD_DEVICE}" || true

###############################################################################
# Validate filesystem
###############################################################################

ACTUAL_FSTYPE="$(blkid -o value -s TYPE "${SSD_PARTITION}" 2>/dev/null || true)"

if [[ -z "${ACTUAL_FSTYPE}" ]]; then
    fatal "No filesystem detected on ${SSD_PARTITION}."
fi

info "Detected filesystem: ${ACTUAL_FSTYPE}"

if [[ "${ACTUAL_FSTYPE}" != "${EXPECTED_FSTYPE}" ]]; then
    fatal \
        "Unexpected filesystem on ${SSD_PARTITION}: " \
        "expected=${EXPECTED_FSTYPE}, actual=${ACTUAL_FSTYPE}"
fi

###############################################################################
# Obtain filesystem UUID
###############################################################################

FILESYSTEM_UUID="$(blkid -o value -s UUID "${SSD_PARTITION}" 2>/dev/null || true)"

if [[ -z "${FILESYSTEM_UUID}" ]]; then
    fatal "Could not determine filesystem UUID for ${SSD_PARTITION}."
fi

info "Filesystem UUID: ${FILESYSTEM_UUID}"

###############################################################################
# Create storage mount point
###############################################################################

mkdir -p "${K8S_STORAGE_ROOT}"

###############################################################################
# Mount local SSD
###############################################################################

if mountpoint -q "${K8S_STORAGE_ROOT}"; then

    info "${K8S_STORAGE_ROOT} is already mounted."

    CURRENT_SOURCE="$(
        findmnt \
            -n \
            -o SOURCE \
            --target "${K8S_STORAGE_ROOT}"
    )"

    info "Current storage source: ${CURRENT_SOURCE}"

else

    info "Mounting ${SSD_PARTITION} on ${K8S_STORAGE_ROOT}."

    mount "${SSD_PARTITION}" "${K8S_STORAGE_ROOT}"

    info "Local SSD mounted successfully."

fi

###############################################################################
# Verify storage mount
###############################################################################

if ! mountpoint -q "${K8S_STORAGE_ROOT}"; then
    fatal \
        "Local Kubernetes storage is not mounted: " \
        "${K8S_STORAGE_ROOT}"
fi

###############################################################################
# Verify mounted filesystem
###############################################################################

MOUNTED_UUID="$(
    findmnt \
        -n \
        -o UUID \
        --target "${K8S_STORAGE_ROOT}" \
        2>/dev/null || true
)"

if [[ -n "${MOUNTED_UUID}" && "${MOUNTED_UUID}" != "${FILESYSTEM_UUID}" ]]; then

    fatal \
        "Wrong filesystem mounted on ${K8S_STORAGE_ROOT}. " \
        "Expected UUID=${FILESYSTEM_UUID}, " \
        "Found UUID=${MOUNTED_UUID}"

fi

###############################################################################
# Create persistent directory structure
###############################################################################

info "Creating persistent Kubernetes directories."

mkdir -p "${K8S_CONFIG_PERSIST}"
mkdir -p "${KUBELET_PERSIST}"
mkdir -p "${CONTAINERD_PERSIST}"

###############################################################################
# Safety check:
# Make sure persistent paths are actually inside the SSD mount.
###############################################################################

verify_path_on_storage()
{
    local path="$1"

    local source

    source="$(
        findmnt \
            -n \
            -o SOURCE \
            --target "${path}" \
            2>/dev/null || true
    )"

    if [[ -z "${source}" ]]; then
        warn "Could not determine filesystem for ${path}."
        return 1
    fi

    return 0
}

###############################################################################
# Bind mount helper
###############################################################################

bind_mount()
{
    local source="$1"
    local target="$2"

    info "Preparing bind mount: ${source} -> ${target}"

    mkdir -p "${source}"
    mkdir -p "${target}"

    ###########################################################################
    # Already mounted?
    ###########################################################################

    if mountpoint -q "${target}"; then

        local current_source

        current_source="$(
            findmnt \
                -n \
                -o SOURCE \
                --target "${target}" \
                2>/dev/null || true
        )"

        info \
            "${target} is already mounted. " \
            "Source=${current_source}"

        return 0
    fi

    ###########################################################################
    # Verify source is actually on the local SSD.
    ###########################################################################

    local source_mount

    source_mount="$(
        findmnt \
            -n \
            -o TARGET \
            --target "${source}" \
            2>/dev/null || true
    )"

    if [[ -z "${source_mount}" ]]; then
        fatal \
            "Persistent source ${source} is not located on a mounted filesystem."
    fi

    ###########################################################################
    # Bind mount.
    ###########################################################################

    mount --bind "${source}" "${target}"

    ###########################################################################
    # Verify.
    ###########################################################################

    if ! mountpoint -q "${target}"; then
        fatal "Bind mount failed: ${target}"
    fi

    info "Bind mount successful: ${target}"
}

###############################################################################
# Mount Kubernetes persistent directories
###############################################################################

bind_mount \
    "${K8S_CONFIG_PERSIST}" \
    "${K8S_CONFIG}"

bind_mount \
    "${KUBELET_PERSIST}" \
    "${KUBELET}"

bind_mount \
    "${CONTAINERD_PERSIST}" \
    "${CONTAINERD}"

###############################################################################
# Final verification
###############################################################################

info "Verifying Kubernetes persistent storage."

verify_mount()
{
    local target="$1"

    if ! mountpoint -q "${target}"; then
        fatal "${target} is NOT mounted."
    fi

    local source

    source="$(
        findmnt \
            -n \
            -o SOURCE \
            --target "${target}" \
            2>/dev/null || true
    )"

    info "${target} <- ${source}"
}

verify_mount "${K8S_STORAGE_ROOT}"
verify_mount "${K8S_CONFIG}"
verify_mount "${KUBELET}"
verify_mount "${CONTAINERD}"

###############################################################################
# Verify all paths resolve to the expected SSD filesystem
###############################################################################

info "Filesystem verification."

df -hT \
    "${K8S_CONFIG}" \
    "${KUBELET}" \
    "${CONTAINERD}" \
    "${K8S_STORAGE_ROOT}"

###############################################################################
# Final lsblk
###############################################################################

info "Final block-device state."

lsblk -o \
    NAME,TYPE,SIZE,FSTYPE,LABEL,UUID,MOUNTPOINTS \
    "${SSD_DEVICE}" || true

###############################################################################
# Completion
###############################################################################

info "Kubernetes persistent storage bootstrap completed successfully."

exit 0
