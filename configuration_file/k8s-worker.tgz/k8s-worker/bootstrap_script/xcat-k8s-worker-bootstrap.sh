#!/bin/bash
###############################################################################
# xcat-k8s-worker-bootstrap.sh
#
# Decides, on every boot, whether this worker node:
#   (a) already has a valid, persisted kubelet identity  -> just start kubelet
#   (b) is a genuinely fresh node                         -> controlled kubeadm join
#   (c) has inconsistent/corrupted local state             -> explicit recovery
#       required, NEVER an automatic silent rejoin
#
# Design rules encoded below (referenced inline as [Rule N]):
#   1. Reboot never implies kubeadm join.
#   2. Persistent kubelet state is the primary local bootstrap indicator.
#   3. The Node object in the API is a secondary validation signal only.
#   4. Bootstrap tokens are temporary credentials.
#   5. No single permanent token is ever distributed fleet-wide.
#   6. Kubelet private keys are never distributed through xCAT.
#   7. Kubelet certificates rotate automatically.
#   8. Lost/inconsistent identity triggers an explicit recovery workflow.
#   9. Hostname / node identity is treated as immutable.
#  10. Storage mounting completes before containerd/kubelet start.
###############################################################################

set -Eeuo pipefail

CONFIG="/etc/xcat/k8s/worker-bootstrap.conf"

# -----------------------------------------------------------------------------
# Logging (stderr + syslog, so failures are visible in `journalctl -u
# k8s-worker-bootstrap` even though this unit is a boot-time oneshot).
# -----------------------------------------------------------------------------
log()  { logger -t xcat-k8s-worker-bootstrap -- "$*"; printf '%s %s\n' "$(date -Is)" "$*" >&2; }
info() { log "INFO: $*"; }
warn() { log "WARN: $*"; }

trap 'log "ERROR: unexpected failure at line ${LINENO}: ${BASH_COMMAND} (rc=$?)"' ERR

[[ -r "$CONFIG" ]] || { log "ERROR: Missing $CONFIG"; exit 1; }
# shellcheck source=/etc/xcat/k8s/worker-bootstrap.conf
source "$CONFIG"

# -----------------------------------------------------------------------------
# Validate configuration up front so failures are explicit, not "unbound
# variable" bash noise three screens down.
# -----------------------------------------------------------------------------
REQUIRED_VARS=(
    K8S_API_ENDPOINT K8S_CA_CERT_HASH K8S_CRI_SOCKET
    K8S_STORAGE_ROOT K8S_CONFIG KUBELET_DIR CONTAINERD_DIR
    BOOTSTRAP_TOKEN_TTL BOOTSTRAP_TOKEN_DIR NODE_STATE_FILE
)
for v in "${REQUIRED_VARS[@]}"; do
    [[ -n "${!v:-}" ]] || { log "ERROR: $v is not set in $CONFIG"; exit 1; }
done

[[ "$K8S_CA_CERT_HASH" =~ ^sha256:[0-9a-f]{64}$ ]] || \
    { log "ERROR: K8S_CA_CERT_HASH is not a well-formed sha256 hash"; exit 1; }
[[ "$K8S_API_ENDPOINT" =~ ^[^[:space:]]+:[0-9]+$ ]] || \
    { log "ERROR: K8S_API_ENDPOINT must be host:port"; exit 1; }

set_state() {
    mkdir -p "$(dirname "$NODE_STATE_FILE")"
    printf '%s\n' "$1" > "${NODE_STATE_FILE}.tmp"
    chmod 0600 "${NODE_STATE_FILE}.tmp"
    mv -f "${NODE_STATE_FILE}.tmp" "$NODE_STATE_FILE"
    info "State=$1"
}

fail() {
    set_state "BOOTSTRAP_FAILED"
    log "ERROR: $*"
    exit 1
}

[[ $EUID -eq 0 ]] || fail "Must run as root"

# -----------------------------------------------------------------------------
# Single-instance guard. systemd oneshot already serializes this, but a stray
# manual re-run (e.g. an operator debugging) must not race the boot-time run.
# -----------------------------------------------------------------------------
exec 200>/run/xcat-k8s-worker-bootstrap.lock
flock -n 200 || fail "Another instance of worker-bootstrap is already running"

# -----------------------------------------------------------------------------
# [Rule 10] Storage must already be mounted. This script never mounts or
# formats anything itself -- that is xcat-k8s-storage-bootstrap.sh's job, and
# systemd ordering (Requires=/After=) guarantees it ran first. Here we only
# verify the guarantee held.
# -----------------------------------------------------------------------------
findmnt -rn -T "$K8S_STORAGE_ROOT" >/dev/null || fail "$K8S_STORAGE_ROOT is not mounted"
mountpoint -q "$K8S_CONFIG"      || fail "$K8S_CONFIG is not a mountpoint"
mountpoint -q "$KUBELET_DIR"     || fail "$KUBELET_DIR is not a mountpoint"
mountpoint -q "$CONTAINERD_DIR"  || fail "$CONTAINERD_DIR is not a mountpoint"

# -----------------------------------------------------------------------------
# [Rule 9] Hostname / node identity is immutable. Because K8S_STORAGE_ROOT is
# node-local SSD, and nodes are stateless/re-imageable via xCAT, we must be
# certain this disk actually belongs to *this* hostname before trusting
# anything on it. A mismatch here means either the wrong disk was attached,
# or xCAT re-provisioned the node under a new name -- both are recovery
# cases, never something to silently paper over.
# -----------------------------------------------------------------------------
IDENTITY_FILE="$K8S_STORAGE_ROOT/node-identity"
CURRENT_HOSTNAME="$(hostname -s)"
[[ "$CURRENT_HOSTNAME" =~ ^[a-z0-9]([-a-z0-9]*[a-z0-9])?$ ]] || \
    fail "Hostname '$CURRENT_HOSTNAME' is not a valid (lowercase RFC1123) node name"

if [[ -s "$IDENTITY_FILE" ]]; then
    RECORDED_HOSTNAME="$(cat "$IDENTITY_FILE")"
    if [[ "$RECORDED_HOSTNAME" != "$CURRENT_HOSTNAME" ]]; then
        set_state "NEEDS_RECOVERY"
        fail "Persistent storage identity mismatch: disk belongs to" \
             "'$RECORDED_HOSTNAME', running host is '$CURRENT_HOSTNAME'." \
             "Refusing to reuse another node's kubelet identity. This" \
             "requires explicit operator recovery, not an automatic join."
    fi
else
    printf '%s\n' "$CURRENT_HOSTNAME" > "$IDENTITY_FILE"
    chmod 0600 "$IDENTITY_FILE"
    info "Recorded node identity '$CURRENT_HOSTNAME' on persistent storage"
fi

# -----------------------------------------------------------------------------
# Bring up containerd. Storage is confirmed mounted, so this is safe per
# [Rule 10].
# -----------------------------------------------------------------------------
systemctl start containerd
systemctl is-active --quiet containerd || fail "containerd is not active"

mkdir -p "$BOOTSTRAP_TOKEN_DIR"
chmod 0700 "$BOOTSTRAP_TOKEN_DIR"
TOKEN_FILE="$BOOTSTRAP_TOKEN_DIR/bootstrap.token"
RECOVERY_ACK_FILE="$BOOTSTRAP_TOKEN_DIR/recovery.ack"

# [Rule 6] Defense in depth: xCAT must never stage private key material next
# to the bootstrap token. If it ever does, refuse to proceed rather than risk
# using/propagating a key we didn't generate locally via kubeadm.
if compgen -G "$BOOTSTRAP_TOKEN_DIR/*.key" >/dev/null 2>&1 || \
   compgen -G "$BOOTSTRAP_TOKEN_DIR/*private*" >/dev/null 2>&1; then
    fail "Private-key-like material found in $BOOTSTRAP_TOKEN_DIR;" \
         "kubelet keys must never be distributed via xCAT"
fi

# =============================================================================
# Classify local kubelet state: NONE (fresh) / VALID / CORRUPT
# [Rule 2] Persistent kubelet state (kubelet.conf + client cert) is the
# primary bootstrap indicator -- checked first, before anything else.
# =============================================================================
KUBELET_CONF="$K8S_CONFIG/kubelet.conf"
CLIENT_CERT="$KUBELET_DIR/pki/kubelet-client-current.pem"

classify_local_state() {
    if [[ ! -s "$KUBELET_CONF" && ! -s "$CLIENT_CERT" ]]; then
        echo "NONE"
        return
    fi
    if [[ ! -s "$KUBELET_CONF" || ! -s "$CLIENT_CERT" ]]; then
        echo "CORRUPT"   # one present without the other: inconsistent
        return
    fi
    if ! openssl x509 -in "$CLIENT_CERT" -checkend 0 -noout >/dev/null 2>&1; then
        echo "CORRUPT"   # unreadable or expired
        return
    fi
    local subject
    subject="$(openssl x509 -in "$CLIENT_CERT" -noout -subject 2>/dev/null || true)"
    if [[ "$subject" != *"system:node:${CURRENT_HOSTNAME}"* ]]; then
        echo "CORRUPT"   # wrong node identity embedded in the cert
        return
    fi
    echo "VALID"
}

STATE="$(classify_local_state)"
info "Local kubelet identity classification: $STATE"

case "$STATE" in

# -----------------------------------------------------------------------------
# EXISTING, VALID identity. [Rule 1] A reboot alone never triggers a join.
# -----------------------------------------------------------------------------
VALID)
    # [Rule 3] The API Node object is a *secondary* signal. We use it to
    # corroborate local trust, never to override it, and never to block
    # startup on a transient network/API outage.
    if timeout 10s kubectl --kubeconfig="$KUBELET_CONF" \
         get node "$CURRENT_HOSTNAME" -o name >/tmp/.node-check.out 2>/tmp/.node-check.err; then
        info "API confirms Node object for '$CURRENT_HOSTNAME' exists"
    else
        if grep -qi 'not found' /tmp/.node-check.err 2>/dev/null; then
            # Local cert is cryptographically valid, but the cluster has no
            # record of this node -- e.g. it was deleted/drained/replaced.
            # That is a genuine inconsistency, not a transient blip.
            set_state "NEEDS_RECOVERY"
            fail "Local kubelet identity is valid but the API server has no" \
                 "matching Node object for '$CURRENT_HOSTNAME'. This requires" \
                 "explicit recovery, not a silent kubelet restart."
        fi
        warn "Could not reach API server to validate Node object" \
             "(treated as non-fatal; local identity remains authoritative" \
             "per Rule 2/3): $(cat /tmp/.node-check.err 2>/dev/null)"
    fi
    rm -f /tmp/.node-check.out /tmp/.node-check.err

    # [Rule 7] Certificate rotation is expected to be handled automatically
    # by the kubelet (rotateCertificates/serverTLSBootstrap). Verify the
    # setting is present rather than silently assuming it.
    KUBELET_CONFIG_YAML="$KUBELET_DIR/config.yaml"
    if [[ -f "$KUBELET_CONFIG_YAML" ]] && ! grep -q 'rotateCertificates: *true' "$KUBELET_CONFIG_YAML"; then
        warn "rotateCertificates is not enabled in $KUBELET_CONFIG_YAML;" \
             "automatic certificate rotation will not occur"
    fi

    set_state "JOINED"
    systemctl enable kubelet >/dev/null 2>&1 || true
    systemctl restart kubelet
    systemctl is-active --quiet kubelet || fail "kubelet failed to start with existing identity"
    info "Existing valid kubelet identity found; kubeadm join is NOT required"
    exit 0
    ;;

# -----------------------------------------------------------------------------
# [Rule 8] CORRUPT/inconsistent local state. This is explicitly NOT treated
# as a fresh node. Auto-rejoining here would silently paper over data loss,
# clock skew, disk mix-ups, or a partially-completed previous join. We stop
# and require an explicit, deliberate recovery acknowledgement.
# -----------------------------------------------------------------------------
CORRUPT)
    set_state "NEEDS_RECOVERY"
    if [[ ! -s "$RECOVERY_ACK_FILE" ]]; then
        fail "Inconsistent local Kubernetes state detected" \
             "(kubelet.conf present=$( [[ -s "$KUBELET_CONF" ]] && echo yes || echo no )," \
             "client cert present=$( [[ -s "$CLIENT_CERT" ]] && echo yes || echo no )." \
             "Automatic recovery is disabled by design [Rule 8]." \
             "An operator/xCAT workflow must review this node and place" \
             "an explicit acknowledgement at $RECOVERY_ACK_FILE" \
             "(and a fresh, unique bootstrap token at $TOKEN_FILE)" \
             "before a rejoin will be attempted."
    fi

    info "Explicit recovery acknowledgement found; performing controlled" \
         "kubeadm reset before rejoin"
    kubeadm reset -f --cri-socket "$K8S_CRI_SOCKET" >/tmp/kubeadm-reset.log 2>&1 || \
        fail "kubeadm reset failed during recovery; see /tmp/kubeadm-reset.log"
    rm -rf "${K8S_CONFIG:?}"/* "${KUBELET_DIR:?}"/pki 2>/dev/null || true
    rm -f "$RECOVERY_ACK_FILE"
    info "Recovery reset complete; proceeding through the fresh-node join path"
    ;&  # fall through into NONE handling intentionally

# -----------------------------------------------------------------------------
# Genuinely fresh node -> controlled, single-use bootstrap.
# -----------------------------------------------------------------------------
NONE)
    # [Rule 4/5] The token is a short-lived, per-node credential dropped by
    # xCAT for this boot only -- never a fleet-wide permanent secret.
    if [[ ! -s "$TOKEN_FILE" ]]; then
        set_state "BOOTSTRAP_REQUIRED"
        fail "No valid kubelet identity and no bootstrap token present at $TOKEN_FILE"
    fi

    chmod 0600 "$TOKEN_FILE"
    chown root:root "$TOKEN_FILE"

    # Enforce the TTL locally too, defense in depth against a stale token
    # left behind by a previous, aborted attempt.
    TTL_RAW="$BOOTSTRAP_TOKEN_TTL"
    TTL_UNIT="${TTL_RAW: -1}"
    TTL_NUM="${TTL_RAW%?}"
    case "$TTL_UNIT" in
        s) TTL_SECONDS="$TTL_NUM" ;;
        m) TTL_SECONDS=$(( TTL_NUM * 60 )) ;;
        h) TTL_SECONDS=$(( TTL_NUM * 3600 )) ;;
        *) fail "Unrecognized BOOTSTRAP_TOKEN_TTL '$TTL_RAW' (expected e.g. 15m/900s/1h)" ;;
    esac
    TOKEN_AGE=$(( $(date +%s) - $(stat -c %Y "$TOKEN_FILE") ))
    if (( TOKEN_AGE > TTL_SECONDS )); then
        rm -f "$TOKEN_FILE"
        fail "Bootstrap token is older than its TTL (${TOKEN_AGE}s > ${TTL_SECONDS}s);" \
             "discarding. xCAT must issue a fresh token."
    fi

    TOKEN="$(cat "$TOKEN_FILE")"
    if ! [[ "$TOKEN" =~ ^[a-z0-9]{6}\.[a-z0-9]{16}$ ]]; then
        rm -f "$TOKEN_FILE"
        fail "Invalid bootstrap token format"
    fi

    set_state "BOOTSTRAPPING"

    JOIN_RC=0
    if ! timeout 120s kubeadm join "$K8S_API_ENDPOINT" \
            --token "$TOKEN" \
            --discovery-token-ca-cert-hash "$K8S_CA_CERT_HASH" \
            --cri-socket "$K8S_CRI_SOCKET" \
            --node-name "$CURRENT_HOSTNAME"
    then
        JOIN_RC=$?
    fi

    # [Rule 4] The credential is single-use and destroyed immediately after
    # use, success or failure -- it must never linger or be reused.
    rm -f "$TOKEN_FILE"

    if [[ "$JOIN_RC" -ne 0 ]]; then
        # Leave the node in a clean, unambiguous state for the next attempt
        # rather than a half-joined state that could be misclassified later.
        kubeadm reset -f --cri-socket "$K8S_CRI_SOCKET" >/tmp/kubeadm-reset.log 2>&1 || true
        fail "kubeadm join failed with rc=$JOIN_RC (node reset for a clean retry;" \
             "see /tmp/kubeadm-reset.log)"
    fi

    # ---------------------------------------------------------------------
    # Verify resulting identity before declaring success.
    # ---------------------------------------------------------------------
    [[ -s "$KUBELET_CONF" ]] || fail "kubeadm join completed but kubelet.conf is missing"
    [[ -s "$CLIENT_CERT"  ]] || fail "kubeadm join completed but kubelet client certificate is missing"

    subject="$(openssl x509 -in "$CLIENT_CERT" -noout -subject 2>/dev/null || true)"
    [[ "$subject" == *"system:node:${CURRENT_HOSTNAME}"* ]] || \
        fail "Post-join certificate identity does not match this node's hostname"

    set_state "JOINED"
    systemctl enable kubelet
    systemctl restart kubelet
    systemctl is-active --quiet kubelet || fail "kubelet failed after successful join"

    info "Worker bootstrap completed successfully via kubeadm join"
    exit 0
    ;;
esac
